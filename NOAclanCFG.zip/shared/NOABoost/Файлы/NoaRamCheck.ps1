$ram = Get-CimInstance Win32_PhysicalMemory
$total = [math]::Round(($ram | Measure-Object Capacity -Sum).Sum / 1GB, 0)
$count = $ram.Count

Write-Host ('Общий объем ОЗУ : {0} ГБ' -f $total)
Write-Host ('Установлено модулей : {0}' -f $count)
Write-Host ''

$ram | Select-Object `
    @{N='Производитель'; E={$_.Manufacturer}}, `
    @{N='Модель'; E={$_.PartNumber.Trim()}}, `
    @{N='Тип'; E={switch($_.SMBIOSMemoryType){24{'DDR3'}26{'DDR4'}30{'DDR5'}default{'Неизвестно'}}}}, `
    @{N='MaxSpeed'; E={'{0} MT/s' -f $_.Speed}}, `
    @{N='CurrentSpeed'; E={'{0} MT/s' -f $_.ConfiguredClockSpeed}}, `
    @{N='Объем'; E={'{0} ГБ' -f [math]::Round($_.Capacity / 1GB, 0)}} |
    Format-Table -AutoSize

$slow = $ram | Where-Object { $_.ConfiguredClockSpeed -lt $_.Speed }
Write-Host ''

if ($slow.Count -eq 0) {
    Write-Host '========================================================'
    Write-Host 'Все модули работают на заявленной частоте.' -ForegroundColor Green
    Write-Host '========================================================'
} else {
    Write-Host '========================================================'
    Write-Host 'ВНИМАНИЕ! Некоторые модули работают ниже заявленной частоты.' -ForegroundColor Yellow
    Write-Host '========================================================'
}

Write-Host ''
Read-Host 'Нажмите Enter для выхода'
