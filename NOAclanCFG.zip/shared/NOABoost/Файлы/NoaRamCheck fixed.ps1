$ram = Get-CimInstance Win32_PhysicalMemory
if (-not $ram) {
    Write-Host 'Не удалось получить данные об ОЗУ через WMI.' -ForegroundColor Red
    Read-Host 'Нажмите Enter для выхода'
    exit 1
}

$total = [math]::Round(($ram | Measure-Object Capacity -Sum).Sum / 1GB, 0)
$count = $ram.Count

Write-Host ('Общий объем ОЗУ : {0} ГБ' -f $total)
Write-Host ('Установлено модулей : {0}' -f $count)
Write-Host ''

$ram | Select-Object `
    @{N='Производитель'; E={$_.Manufacturer}}, `
    @{N='Модель'; E={$_.PartNumber.Trim()}}, `
    @{N='Тип'; E={switch($_.SMBIOSMemoryType){24{'DDR3'}26{'DDR4'}30{'DDR5'}default{'Неизвестно'}}}}, `
    @{N='MaxSpeed'; E={'{0} MT/s' -f $_.Speed}}, `
    @{N='CurrentSpeed'; E={'{0} MT/s' -f $_.ConfiguredClockSpeed}}, `
    @{N='Объем'; E={'{0} ГБ' -f [math]::Round($_.Capacity / 1GB, 0)}} |
    Format-Table -AutoSize

$unknown = $ram | Where-Object { -not $_.ConfiguredClockSpeed -or -not $_.Speed }
$slow = $ram | Where-Object { $_.ConfiguredClockSpeed -and $_.Speed -and $_.ConfiguredClockSpeed -lt $_.Speed }
Write-Host ''

if ($unknown.Count -gt 0) {
    Write-Host '========================================================'
    Write-Host 'ВНИМАНИЕ! Не удалось определить частоту одного или нескольких модулей (WMI вернул пустое значение).' -ForegroundColor Yellow
    Write-Host '========================================================'
} elseif ($slow.Count -eq 0) {
    Write-Host '========================================================'
    Write-Host 'Все модули работают на заявленной частоте.' -ForegroundColor Green
    Write-Host '========================================================'
} else {
    Write-Host '========================================================'
    Write-Host 'ВНИМАНИЕ! Некоторые модули работают ниже заявленной частоты.' -ForegroundColor Yellow
    Write-Host '========================================================'
}

Write-Host ''
Write-Host 'Примечание: значение "заявленная частота" здесь берётся из WMI (Win32_PhysicalMemory.Speed)' -ForegroundColor DarkGray
Write-Host 'и может не совпадать с частотой XMP/DOCP на коробке модуля. Для точной проверки' -ForegroundColor DarkGray
Write-Host 'разгона сверяйте ConfiguredClockSpeed со спецификацией XMP/DOCP профиля в BIOS.' -ForegroundColor DarkGray

Write-Host ''
Read-Host 'Нажмите Enter для выхода'
