@echo off
start main.cpl @1
exit