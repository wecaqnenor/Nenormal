@echo off
start ms-settings:display-advancedgraphics-default
exit