@echo off
start ms-settings:systemcomponents
exit